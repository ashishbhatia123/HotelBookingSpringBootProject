package com.startup.HotelBooking.dao;

import com.startup.HotelBooking.bean.AwsTestBean;

public interface IAwsTestDaoImpl {

	public boolean AddAwsTest(AwsTestBean awsTestbean);
	public AwsTestBean showAwsTest();
}
